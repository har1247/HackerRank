//
//  ViewController.swift
//  BopIt
//
//  Created by Jaspinder Singh on 2019-03-11.
//  Copyright © 2019 Jaspinder Singh. All rights reserved.
//

import UIKit

class pReader {
    var levels:[[String]] = [[""]]
    func readPlist(_fileURL:    URL)    ->    [[String]]?    {
        guard
            let data = try? Data(contentsOf: _fileURL)
            else    {
                return nil }
        guard let result = try? PropertyListSerialization.propertyList(from:    data,    options:    [],    format:    nil)     as?    [[String]]
            else    {
                return    nil    }
        return result
    }
    init(){
        let _fileURL = Bundle.main.url(forResource: "Levels", withExtension: "plist")
        let dataText =  readPlist ( _fileURL: _fileURL! )!
        
        levels = dataText
        
    }
}

class ViewController: UIViewController {

    @IBOutlet var InstructionLabel: UILabel!
    @IBOutlet var Status: UILabel!
    
    var gesture = "aa"
    var levels = pReader().levels
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(swipeU))
        swipeUp.direction = .up
        self.view.addGestureRecognizer(swipeUp)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(swipeL))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
    
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(swipeD))
        swipeDown.direction = .down
        self.view.addGestureRecognizer(swipeDown)
    }
    
    @IBAction func easyButton(_ sender: Any) {
        InstructionLabel.text = ""
        Status.text = ""
        let index = 0
        DispatchQueue.global(qos: .background).async {
            var score = 0
            for i in self.levels[index]{
                DispatchQueue.main.sync {
                    self.InstructionLabel.text = i
                }
                self.gesture = "aa"
                sleep(5)
                print(self.gesture)
                if(self.gesture != i) {
                    DispatchQueue.main.sync {
                        self.Status.text = "Time out! Try again"
                    }
                    break
                }
                else{
                    score+=1
                    let array = ["Nice going", "Keep it up", "Awesome", "Keep going", "Good", "You play well", "You are winning", "Almost there"]
                    DispatchQueue.main.sync {
                        self.Status.text = array.randomElement()
                    }
                }
                if(score == self.levels[index].count){
                    DispatchQueue.main.sync {
                        self.Status.text = "You won the level! Try another level"
                    }
                }
            }
        }
    }
    @IBAction func mediumButton(_ sender: Any) {
        InstructionLabel.text = ""
        Status.text = ""
        let index = 1
        DispatchQueue.global(qos: .background).async {
            var score = 0
            for i in self.levels[index]{
                DispatchQueue.main.sync {
                    self.InstructionLabel.text = i
                }
                self.gesture = "aa"
                sleep(4)
                print(self.gesture)
                if(self.gesture != i) {
                    DispatchQueue.main.sync {
                        self.Status.text = "Time out! Try again"
                    }
                    break
                }
                else{
                    score+=1
                    let array = ["Nice going", "Keep It Up", "Awesome", "Keep going", "Good", "You play well", "You are winning", "Almost there"]
                    DispatchQueue.main.sync {
                        self.Status.text = array.randomElement()
                    }
                }
                if(score == self.levels[index].count){
                    DispatchQueue.main.sync {
                        self.Status.text = "You won the level! Try another level"
                    }
                }
            }
        }
    }
    @IBAction func difficultButton(_ sender: Any) {
        InstructionLabel.text = ""
        Status.text = ""
        let index = 2
        DispatchQueue.global(qos: .background).async {
            var score = 0
            for i in self.levels[index]{
                DispatchQueue.main.sync {
                    self.InstructionLabel.text = i
                }
                self.gesture = "aa"
                sleep(3)
                print(self.gesture)
                if(self.gesture != i) {
                    DispatchQueue.main.sync {
                        self.Status.text = "Time out! Try again"
                    }
                    break
                }
                else{
                    score+=1
                    let array = ["Nice going", "Keep It Up", "Awesome", "Keep going", "Good", "You play well", "You are winning", "Almost there"]
                    DispatchQueue.main.sync {
                        self.Status.text = array.randomElement()
                    }
                }
                if(score == self.levels[index].count){
                    DispatchQueue.main.sync {
                        self.Status.text = "You won the level! Try another level"
                    }
                }
            }
        }
    }
    @objc func swipeD() {
        gesture = "Swipe Down"
    }
    @objc func swipeL() {
        gesture = "Swipe Left"
    }
    @objc func swipeU(){
        gesture = "Swipe Up"
    }
    @IBAction func tapIt(_ sender: Any) {
        gesture = "Tap It"
    }
    @IBAction func pinchIt(_ sender: Any) {
        gesture = "Pinch It"
    }
    @IBAction func swipeIt(_ sender: Any) {
        gesture = "Swipe Right"
    }
    @IBAction func rotateIt(_ sender: Any) {
        gesture = "Rotate It"
    }
}
